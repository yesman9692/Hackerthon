import com.ui.MainUI;

public class example {

	public static void main(String[] args) {
		MainUI ui=new MainUI();
	}
	
}
