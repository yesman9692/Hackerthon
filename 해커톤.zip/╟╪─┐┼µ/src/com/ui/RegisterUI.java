package com.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.datatype.Member;
import com.function.Function;
import com.function.Resolution;

public class RegisterUI extends JFrame implements ActionListener {

	private JTextField text_menu = null,text_restaurant = null;
	

	private JButton button_add = null;

	private Function function = new Function();

	public RegisterUI() {
		super("�޴��� �߰��غ���~");

		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(Resolution.x / 2 - 550, Resolution.y / 2 - 500, 640, 900);
		setResizable(true);

		JLabel label_menu = new JLabel("�߰� �� �޴�  ");
		JLabel label_restaurant = new JLabel("�Ĵ�  ");

		label_menu.setBounds(110, 100, 100, 20);
		label_restaurant.setBounds(110, 290, 100, 20);

		text_menu = new JTextField();
		text_restaurant = new JTextField();

		text_menu.setBounds(110, 150, 200, 90);
		text_restaurant.setBounds(110, 350, 200, 90);

		button_add = new JButton("�߰�~^^");

		button_add.setBounds(110, 540, 400, 100);

		button_add.addActionListener(this);

		add(label_menu);
		add(label_restaurant);

		add(text_menu);
		add(text_restaurant);
		add(button_add);

		setVisible(false);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		Object o = e.getSource();
		String menu = text_menu.getText();

		String restaurant = text_restaurant.getText();

		BufferedReader in = null;

		String DATA_FILE = "member_info.txt";
		String DATA_FILE2 = "menu_info.txt";
		
		boolean a = true;
		String k;

		if (o == button_add) {
			if (menu.equals("") || restaurant.equals(""))

				JOptionPane.showMessageDialog(null, "�޴��� �Ĵ��� �Է����ּ���.");
			else {

				function.add(new Member(menu, restaurant));
				JOptionPane.showMessageDialog(null, "��ݸ��� ������ �߰�����");
				setVisible(false);

			}
		}
	}
}
