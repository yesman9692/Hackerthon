package com.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;

import com.function.Function;
import com.function.Resolution;

public class MainUI extends JFrame implements ActionListener {

	private JTextField text_id = null;
	private JPasswordField text_passwd = null;
	private JButton button_delete = null, button_register = null,button_list=null,button_recommend=null;
	private Function function = new Function();
	
	private RegisterUI registerui = new RegisterUI();
	private DeleteUI deleteui = new DeleteUI();
	private MemberListUI memberlistui = new MemberListUI();
	
	public MainUI() {
		
		super("�޴���õ�ص����~");
		
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(Resolution.x/2-550, Resolution.y/2-500,640,900);
		setResizable(false);
		
		JLabel label_id=new JLabel("�ȳ��ϼ��� ����� �Ѽ� ��췯 �� 15�й� �Դϴ�.");
		JLabel label_passwd=new JLabel("���ϴ� �޴��� �߰�, ����, ��õ�ϴ� ��ɵ��� ����ſ���");
		
		label_id.setBounds(20,20,400,40);
		label_passwd.setBounds(20,70,400,40);
		
		
		button_register=new JButton("�޴��߰�");
		button_delete=new JButton("�̰� �� �԰� �;��");
		button_delete.setFont(new Font("����",Font.ITALIC,20));
	    button_delete.setBackground(Color.cyan);
		
		button_list=new JButton("�ֱٿ� �Ծ���~");
		button_recommend=new JButton("��õ�ص帱�Կ�");
		
		
		button_register.setBounds(110,190,400,100);
		button_delete.setBounds(110,340,400,100);
		button_list.setBounds(110,490,400,100);
		button_recommend.setBounds(110,640,400,100);
		
		button_delete.addActionListener(this);
		button_register.addActionListener(this);
		button_list.addActionListener(this);
		button_recommend.addActionListener(this);
		
		add(label_id);
		add(label_passwd);
	
		add(button_register);
		add(button_delete);
		
		add(button_list);
		add(button_recommend);
		setVisible(true);
	}
@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		String ko=function.recommendMenu();
		 if (o == button_delete) {
			deleteui.setVisible(true);
		}
		else if (o == button_register) {
			registerui.setVisible(true);
		}
		
		else if(o== button_list) {
			memberlistui.setVisible(true);
		}
		 
		else if (o == button_recommend) {
			JOptionPane.showMessageDialog(null, ko);
			

			
	
		}

	}

}
